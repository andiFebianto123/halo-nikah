import store from 'store/dist/store.legacy';

window.store = store;
