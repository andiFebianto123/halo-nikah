import * as $ from 'jquery';

export default function Box() {
    return(
        <>
            <div>Hello world</div>
        </>
    )
}