@php
    $text = $value; 
@endphp
<span>{{ $text }}</span>