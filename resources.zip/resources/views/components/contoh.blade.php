<div class="mb-10">
    <p>Hallo dek ini adalah komponent contoh</p>
</div>