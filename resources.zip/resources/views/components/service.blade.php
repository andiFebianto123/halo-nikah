<div class="col-md-12">
    <div class="section-title">
        <h2 class="ec-title">Our Services</h2>
    </div>
</div>
<div class="ec_ser_block">
    <div class="ec_ser_content ec_ser_content_1 col-sm-12">
        <div class="ec_ser_inner">
            <div class="ec-service-image">
                <i class="fi fi-ts-stars"></i>
            </div>
            <div class="ec-service-desc">
                <h2>Worldwide Delivery</h2>
                <p>For Order Over $100</p>
            </div>
        </div>
    </div>
    <div class="ec_ser_content ec_ser_content_2 col-sm-12">
        <div class="ec_ser_inner">
            <div class="ec-service-image">
                <i class="fi fi-ts-tachometer-fast"></i>
            </div>
            <div class="ec-service-desc">
                <h2>Next Day delivery</h2>
                <p>UK Orders Only</p>
            </div>
        </div>
    </div>
    <div class="ec_ser_content ec_ser_content_3 col-sm-12">
        <div class="ec_ser_inner">
            <div class="ec-service-image">
                <i class="fi fi-ts-circle-phone"></i>
            </div>
            <div class="ec-service-desc">
                <h2>Best Online Support</h2>
                <p>Hours: 8AM -11PM</p>
            </div>
        </div>
    </div>
    <div class="ec_ser_content ec_ser_content_4 col-sm-12">
        <div class="ec_ser_inner">
            <div class="ec-service-image">
                <i class="fi fi-ts-badge-percent"></i>
            </div>
            <div class="ec-service-desc">
                <h2>Return Policy</h2>
                <p>Easy & Free Return</p>
            </div>
        </div>
    </div>
    <div class="ec_ser_content ec_ser_content_5 col-sm-12">
        <div class="ec_ser_inner">
            <div class="ec-service-image">
                <i class="fi fi-ts-donate"></i>
            </div>
            <div class="ec-service-desc">
                <h2>30% money back</h2>
                <p>For Order Over $100</p>
            </div>
        </div>
    </div>
</div>