<div class="col-md-12">
    <div class="section-title">
        <h2 class="ec-title">Our Services</h2>
    </div>
</div>
<div class="ec_ser_block">
    <div class="ec_ser_content ec_ser_content_1 col-sm-12">
        <div class="ec_ser_inner">
            <div class="ec-service-image">
                <i class="fi fi-rr-star"></i>
            </div>
            <div class="ec-service-desc">
                <h2>Vendor & Produk Pernikahan Terlengkap</h2>
                <h2>di Semarang</h2>
                {{-- <p>For Order Over $100</p> --}}
            </div>
        </div>
    </div>
    <div class="ec_ser_content ec_ser_content_2 col-sm-12">
        <div class="ec_ser_inner">
            <div class="ec-service-image">
                <i class="fi fi-rr-heart"></i>
            </div>
            <div class="ec-service-desc">
                <h2>Sesuaikan Pesanan dengan Impian Anda</h2>
                <p></p>
            </div>
        </div>
    </div>
    <div class="ec_ser_content ec_ser_content_3 col-sm-12">
        <div class="ec_ser_inner">
            <div class="ec-service-image">
                <i class="fi fi-ts-circle-phone"></i>
            </div>
            <div class="ec-service-desc">
                <h2>Respon Cepat Melalui WhatsApp</h2>
                {{-- <p>Hours: 8AM -11PM</p> --}}
            </div>
        </div>
    </div>
    <div class="ec_ser_content ec_ser_content_4 col-sm-12">
        <div class="ec_ser_inner">
            <div class="ec-service-image">
                <i class="fi fi-rr-room-service"></i>
            </div>
            <div class="ec-service-desc">
                <h2>Gratis Konsultasi Sebelum Membeli</h2>
                {{-- <p>Easy & Free Return</p> --}}
            </div>
        </div>
    </div>
</div>